/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controler.cliente;

import Controler.conexao.Conexao;
import static Controler.conexao.Conexao.con;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.Cliente.Cliente;

/**
 *
 * @author Rafael
 */
public class ClienteDao {
    /*
    public static void insereUsuario(Cliente cliente) throws SQLException {
                    
            PreparedStatement stmt = null;
            Connection con = null;
            
		
			con = Conexao.getConex();
			stmt = con.prepareStatement("insert into cliente (Nome, DataNasc, Email, Cpf) values (?,?,?,?);");
			stmt.setString(1, cliente.getNome());
                        stmt.setDate(2,cliente.getNascimento()));
                        stmt.setString(3, cliente.getEmail());
                        stmt.setString(4,cliente.getCpf());
                        
			
			
			stmt.executeUpdate();

			con.setAutoCommit(false);
			con.commit();

		

	}
    */
    
    
    

	public static void exibir(ArrayList<Cliente> clientes) throws SQLException {

		
			con = Conexao.getConex();
			Statement stmt = con.createStatement();
			ResultSet resultado = stmt.executeQuery("select *from cliente; ");

			while (resultado.next()) {
                            Cliente cliente = new Cliente();
                            cliente.setNome(resultado.getString("nome"));
                            cliente.setCpf(resultado.getString("Cpf"));
                            //cliente.setAniversario(resultado.getDate("DataNasc"));
                            cliente.setEmail(resultado.getString("email"));
                            clientes.add(cliente);
                            
			}
                        
                        Conexao.closeConx(con, stmt);
			

	}
        
        public static void exibir(ArrayList<Cliente> clientes, String nome) throws SQLException {
                    PreparedStatement stmt = null;
                    Connection conx = null;
                    ResultSet resultado;
                    conx = Conexao.getConex();
                    stmt = conx.prepareStatement("select *from cliente where nome like  ?");
                    stmt.setString(1, nome+"%");
                    resultado = stmt.executeQuery();
                        
                        
			
                        

			while (resultado.next()) {
                            Cliente cliente = new Cliente();
                            cliente.setNome(resultado.getString("nome"));
                            cliente.setCpf(resultado.getString("Cpf"));
                            //cliente.setAniversario(resultado.getDate("DataNasc"));
                            cliente.setEmail(resultado.getString("email"));
                            clientes.add(cliente);
                            
			}
                        
                        Conexao.closeConx(con, stmt);
			

	}
          public static void deletar(String nome, String cpf) throws SQLException {
                    PreparedStatement stmt = null;
                    Connection conx = null;
                    ResultSet resultado;
                    conx = Conexao.getConex();
                    stmt = conx.prepareStatement("delete from cliente where nome =? and cpf = ?");
                    stmt.setString(1, nome);
                    stmt.setString(2, cpf);
                    
                    stmt.executeUpdate();
                    con.setAutoCommit(false);
                    con.commit();
                        
                        
			
                        

			
                        
                        Conexao.closeConx(con, stmt);
			

	}

    
    }
