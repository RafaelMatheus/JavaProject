/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controler.conexao;

/**
 *
 * @author Rafael
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class Conexao {

	public static Connection con = null;
	private static String Driver = "com.mysql.jdbc.Driver";
	private static String urlLocalHost = "jdbc:mysql://localhost/bancojava";
	private static String user = "root";
	private static String pass = "";

	public static Connection getConex() {

		try {
			Class.forName(Driver);
			con = DriverManager.getConnection(urlLocalHost, user, pass);
                        
		} catch (ClassNotFoundException e) {
                    JOptionPane.showMessageDialog(null, "Não foi encontrado um banco de dados", "Erro", JOptionPane.ERROR_MESSAGE);
		} catch (SQLException e) {

			JOptionPane.showMessageDialog(null, "Impossivel se comunicar com um banco de dados","Erro", JOptionPane.ERROR_MESSAGE);
		} finally {

			return con;
		}
	}

	public static void closeConx(Connection con) {
		if (con != null)
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	}

	public static void closeConx(Connection con, java.sql.PreparedStatement stmt) {
		closeConx(con);
		if (stmt != null)
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
        
        
        public static void closeConx(Connection con, Statement stmt) {
		closeConx(con);
		if (stmt != null)
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}