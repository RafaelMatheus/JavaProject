/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.Cliente;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Rafael
 */
public class Cliente {

    
  

    private String nome;
    private String cpf;
    private String sexo;
    private Date aniversario;
    private Endereco endereco;
    private String email;
    

    public Cliente(String nome, String cpf, String sexo, Date aniversario) {
        this.nome = nome;
        this.cpf = cpf;
        this.sexo = sexo;
        this.aniversario = aniversario;
        this.endereco = endereco;
        
    }

    public Cliente() {
    }

   
    public Cliente(String nome, String cpf, String sexo, Date aniversario, Endereco endereco, String email) {
        this.nome = nome;
        this.cpf = cpf;
        this.sexo = sexo;
        this.aniversario = aniversario;
        this.endereco = endereco;
        this.email = email;
    }

   

    

    public String getNome() {
        return nome;
    }


    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public Date getAniversario() {
        System.out.println(aniversario);
        return aniversario;
    }

    public void setAniversario(Date aniversario) {
        this.aniversario = aniversario;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public String getEmail() {
       return email;
    }
    
    
}
