/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.agenda;

/**
 *
 * @author Rafael
 */
public class Agenda {
    private String idCliente;
    private String dataCob;
    private String dataComp; 

    public String getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    public String getDataCob() {
        return dataCob;
    }

    public void setDataCob(String dataCob) {
        this.dataCob = dataCob;
    }

    public String getDataComp() {
        return dataComp;
    }

    public void setDataComp(String dataComp) {
        this.dataComp = dataComp;
    }
    
}
