/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controler.conexao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTextField;
import model.Cliente.LoginSenha;


/**
 *
 * @author Rafael
 */

public class LoginDao {
    
    
    
    
    public static void exibir(ArrayList<LoginSenha> logins) {
     Statement stmt = null;
       Connection con = null;
     
       
		try {
                   con =  Conexao.getConex();
                    stmt = con.createStatement();
                    ResultSet resultado = stmt.executeQuery("select *from login  ");

			while (resultado.next()) {
                            LoginSenha login = new LoginSenha();
                            login.setLogin(resultado.getString("login"));
                            login.setSenha(resultado.getString("senha"));
                            logins.add(login);
                            
                                    
                            }
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
                    
			Conexao.closeConx(con, stmt);
                        
		}
        
	}
    public static boolean exibir( String nome, String senha) throws SQLException {
     
        LoginSenha logins = new LoginSenha();
        PreparedStatement stmt = null;
        Connection con = null;
       
		try {
                   con =  Conexao.getConex();
                    stmt =  con.prepareCall("select * from login where login = ? and senha = ?");
                    stmt.setString(1, nome);
                    stmt.setString(2, senha);
                    
                   ResultSet resultado = stmt.executeQuery();
                    
			while (resultado.next()) {
                            
                            logins.setLogin(resultado.getString("login"));
                            logins.setSenha(resultado.getString("senha"));
                                      
                            }
                        
			

		} 
		finally {
                        if(logins.getLogin().equals(nome)){
                            if(logins.getSenha().equals(senha)){
                                return true;
                            }
                        }
                    
			Conexao.closeConx(con, stmt);
                        
		}
        return false;
        
        
	}
    
    	
    public static void insereUsuario (LoginSenha login) throws SQLException {
                    
            PreparedStatement stmt = null;
            Connection con = null;
            
		
			con = Conexao.getConex();
			stmt = con.prepareStatement("insert into login (login, senha) values (?,?)");
			stmt.setString(1, login.getLogin());
			stmt.setString(2, login.getSenha());
			
			stmt.executeUpdate();

			con.setAutoCommit(false);
			con.commit();

		

	}
    
    public static void deleta(String login, String senha) throws SQLException {

            PreparedStatement stmt = null;
            Connection con = null;

		
			con = Conexao.getConex();
			stmt = con.prepareStatement("delete from login where login = ? and senha = ?");
			stmt.setString(1,login);
                        stmt.setString(2, senha);
			
			
			stmt.executeUpdate();

			con.setAutoCommit(false);
			con.commit();

		

	}
    
     public static void deleta(String login) throws SQLException {
            Connection con = null;
            PreparedStatement stmt = null;
            

		
			con = Conexao.getConex();
			stmt = con.prepareStatement("delete from login where login = ?");
			stmt.setString(1,login);
                      
			
			stmt.executeUpdate();

			con.setAutoCommit(false);
			con.commit();

		

	}
     
     
     public static void atualiza(String novoLogin, String antigoLogin) throws SQLException {
                Connection con = null;
                PreparedStatement stmt = null;

		
			con = Conexao.getConex();
			stmt = con.prepareStatement("update login set login = ? where login = ?");
                        stmt.setString(1, novoLogin);
                        stmt.setString(2, antigoLogin);
                        
			stmt.executeUpdate();

			con.setAutoCommit(false);
			con.commit();

		

	}

    public static void atualizaSenha( String senhaAntiga , String novaSenha) throws SQLException {
                Connection con = null;
                PreparedStatement stmt = null;

		
			con = Conexao.getConex();
			stmt = con.prepareStatement("update login set senha = ? where senha = ?");
                        stmt.setString(1, senhaAntiga);
                        stmt.setString(2, novaSenha);
                        
			stmt.executeUpdate();

			con.setAutoCommit(false);
			con.commit();

		

	}

    
}
