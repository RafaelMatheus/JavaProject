/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controler.produto;

import Controler.conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.produto.Produto;

/**
 *
 * @author Rafael
 */
public class ProdutoDao {
    public static void insereProduto(Produto produto) throws SQLException {
                    
            PreparedStatement stmt = null;
            Connection con = null;
            
			con = Conexao.getConex();
			stmt = con.prepareStatement("insert into produto (nome, descricao, preco, categoria, quantidade, codBarras) values (?,?,?,?,?,?) ");
			
                        stmt.setString(1, produto.getNome());
                        stmt.setString(2, produto.getDescricao());
                        stmt.setFloat(3, produto.getPreco());
                        stmt.setString(4, produto.getCategoria());
                        stmt.setInt(5, produto.getQuantidade());
                        stmt.setString(6, produto.getCodBarras());
                        
			stmt.executeUpdate();

			con.setAutoCommit(false);
			con.commit();

		Conexao.closeConx(con, stmt);

	}
    public static void listarCategoria(ArrayList<Produto> produtos) throws SQLException{
             PreparedStatement stmt = null;
            Connection con = null;
            
			con = Conexao.getConex();
			stmt = con.prepareStatement("select categoria from categoria");
                        ResultSet resultado = stmt.executeQuery();
                        
                        
                        while(resultado.next()){
                            Produto produto = new Produto();
                            produto.setCategoria(resultado.getString("categoria"));
                            produtos.add(produto);
                        }
                      Conexao.closeConx(con, stmt);
                        
			
        
    }
    
}
