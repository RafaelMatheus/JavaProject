/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controler.cliente;

import Controler.conexao.Conexao;
import static Controler.conexao.Conexao.con;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import model.Cliente.Cliente;

/**
 *
 * @author Rafael
 */
public class ClienteDao {
   
    private static String cpfAntigo;

    public static String getCpfAntigo() {
        return cpfAntigo;
    }

    public static void setCpfAntigo(String cpfAntigo) {
        ClienteDao.cpfAntigo = cpfAntigo;
    }
    
    

	public static void exibir(ArrayList<Cliente> clientes) throws SQLException {

		
			con = Conexao.getConex();
			Statement stmt = con.createStatement();
			ResultSet resultado = stmt.executeQuery("select *from cliente; ");

			while (resultado.next()) {
                            Cliente cliente = new Cliente();
                            cliente.setNome(resultado.getString("nome"));
                            cliente.setCpf(resultado.getString("Cpf"));
                            cliente.setEndereco(resultado.getString("Endereco"));
                            cliente.setAniversario(resultado.getString("DataNasc"));
                            cliente.setEmail(resultado.getString("email"));
                            clientes.add(cliente);
                            
			}
                        
                        Conexao.closeConx(con, stmt);
			

	}
                
        public static void exibir(ArrayList<Cliente> clientes, String nome) throws SQLException {
                    PreparedStatement stmt = null;
                    Connection conx = null;
                    ResultSet resultado;
                    conx = Conexao.getConex();
                    stmt = conx.prepareStatement("select *from cliente where nome like  ?");
                    stmt.setString(1, nome+"%");
                    resultado = stmt.executeQuery();
                        
                        
			
                        

			while (resultado.next()) {
                            Cliente cliente = new Cliente();
                            cliente.setNome(resultado.getString("nome"));
                            cliente.setCpf(resultado.getString("Cpf"));
                            cliente.setEndereco(resultado.getString("endereco"));
                            cliente.setEmail(resultado.getString("email"));
                            clientes.add(cliente);
                            
			}
                        
                        Conexao.closeConx(con, stmt);
			

	}
          public static void deletar(String nome, String cpf) throws SQLException {
                    PreparedStatement stmt = null;
                    Connection conx = null;
                    conx = Conexao.getConex();
                    stmt = conx.prepareStatement("delete from cliente where cpf = ?");
                    stmt.setString(1, cpf);
                    
                    //stmt.setString(2, cpf);
                    
                    stmt.executeUpdate();
                    con.setAutoCommit(false);
                    con.commit();
                        
                    Conexao.closeConx(con, stmt);
			

	}
          
          
          
       public static void insereUsuario(Cliente cliente) throws SQLException {
                    
            PreparedStatement stmt = null;
            Connection con = null;
            
			con = Conexao.getConex();
			stmt = con.prepareStatement("insert into cliente (Nome, DataNasc, Cpf, Sexo, Endereco, NumeroCasa, Cidade, Bairro, Estado, Email, Telefone1, Telefone2, Complemento) values (?,?,?,?,?,?,?,?,?,?,?,?,?);");
			stmt.setString(1, cliente.getNome());
                        stmt.setString(2, cliente.getAniversario());
                        stmt.setString(3,cliente.getCpf());
                        stmt.setString(4, cliente.getSexo());
    		        stmt.setString(5, cliente.getEndereco());
                        stmt.setString(6, cliente.getNumeroCasa());
                        stmt.setString(7, cliente.getCidade());
                        stmt.setString(8, cliente.getBairro());
                        stmt.setString(9, cliente.getEstado());
                        stmt.setString(10, cliente.getEmail());
                        stmt.setString(11, cliente.getTelefone1());
                        stmt.setString(12, cliente.getTelefone2());
                        stmt.setString(13, cliente.getComplemento());
    
                        
			stmt.executeUpdate();

			con.setAutoCommit(false);
			con.commit();

		Conexao.closeConx(con, stmt);

	}
       public static void atualizar(Cliente cliente) throws SQLException{
             Connection con = null;
              PreparedStatement stmt = null;

		
			con = Conexao.getConex();
			stmt = con.prepareStatement("update cliente set Nome = ?, DataNasc = ?, Cpf = ?, Sexo = ?, Endereco = ?, NumeroCasa = ?, Cidade = ?, Bairro = ?, Estado = ?, Email = ?, Telefone1 = ?, Telefone2 = ?, Complemento = ? where cpf = ?;");
			
                        stmt.setString(1, cliente.getNome());
                        stmt.setString(2, cliente.getAniversario());
                        stmt.setString(3,cliente.getCpf());
                        stmt.setString(4, cliente.getSexo());
    		        stmt.setString(5, cliente.getEndereco());
                        stmt.setString(6, cliente.getNumeroCasa());
                        stmt.setString(7, cliente.getCidade());
                        stmt.setString(8, cliente.getBairro());
                        stmt.setString(9, cliente.getEstado());
                        stmt.setString(10, cliente.getEmail());
                        stmt.setString(11, cliente.getTelefone1());
                        stmt.setString(12, cliente.getTelefone2());
                        stmt.setString(13, cliente.getComplemento());
                        stmt.setString(14, ClienteDao.cpfAntigo);
                        
                        stmt.executeUpdate();
                        con.setAutoCommit(false);
			con.commit();
                        
                        Conexao.closeConx(con, stmt);
                        
                        
                        
           
       }
    
    }
