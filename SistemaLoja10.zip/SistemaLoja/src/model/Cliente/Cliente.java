/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.Cliente;


/**
 *
 * @author Rafael
 */
public class Cliente {

    public static String retornoCpf(String text) {
        String primeiros3 = null;
        String segundos3 = null;
        String terceiro3 = null;
        String quarto2 = null;
        primeiros3 = text.substring(0,3);
        segundos3 = text.substring(4,7);
        terceiro3 = text.substring(8,11);
        quarto2 = text.substring(12);
        
        
        return primeiros3 + segundos3 + terceiro3 + quarto2;
        
    }

    public Cliente(String nome, String aniversario, String cpf, String sexo, String endereco, String numeroCasa, String cidade, String bairro, String estado, String email, String telefone1, String telefone2) {
        this.nome = nome;
        this.aniversario = aniversario;
        this.cpf = cpf;
        this.sexo = sexo;
        this.endereco = endereco;
        this.numeroCasa = numeroCasa;
        this.cidade = cidade;
        this.bairro = bairro;
        this.estado = estado;
        this.email = email;
        this.telefone1 = telefone1;
        this.telefone2 = telefone2;
    }

    public Cliente() {
    }

    public Cliente(String nome, String aniversario, String cpf, String sexo, String endereco, String numeroCasa, String cidade, String bairro, String estado, String email, String telefone1, String telefone2, String complemento) {
        this.nome = nome;
        this.aniversario = aniversario;
        this.cpf = cpf;
        this.sexo = sexo;
        this.endereco = endereco;
        this.numeroCasa = numeroCasa;
        this.cidade = cidade;
        this.bairro = bairro;
        this.estado = estado;
        this.email = email;
        this.telefone1 = telefone1;
        this.telefone2 = telefone2;
        this.complemento = complemento;
    }

    private String nome;
    private String aniversario;
    private String cpf;
    private String sexo;
    private String endereco;
    private String numeroCasa;
    private String cidade;
    private String bairro;
    private String estado;
    private String email;
    private String telefone1;
    private String telefone2;
    private String complemento;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getAniversario() {
        return aniversario;
    }

    public void setAniversario(String aniversario) {
        this.aniversario = aniversario;
    }

    public String getCpf() {
        
        
        
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getNumeroCasa() {
        return numeroCasa;
    }

    public void setNumeroCasa(String numeroCasa) {
        this.numeroCasa = numeroCasa;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone1() {
        return telefone1;
    }

    public void setTelefone1(String telefone1) {
        this.telefone1 = telefone1;
    }

    public String getTelefone2() {
        return telefone2;
    }

    public void setTelefone2(String telefone2) {
        this.telefone2 = telefone2;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    
    
}

   

 