/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controler.produto;

import Controler.conexao.Conexao;
import static Controler.conexao.Conexao.con;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.produto.Produto;

/**
 *
 * @author Rafael
 */
public class ProdutoDao {
    
   public static void insereProduto(Produto produto) throws SQLException {
                    
            PreparedStatement stmt = null;
            Connection con = null;
            
			con = Conexao.getConex();
			stmt = con.prepareStatement("insert into produto (nome, codBarras, descricao, preco, categoria, quantidade) values (?,?,?,?,?,?);");
			stmt.setString(1, produto.getNome());
                        stmt.setString(2, produto.getCodBarras());
                        stmt.setString(3, produto.getDescricao());
                        stmt.setFloat(4,produto.getPreco());
                        stmt.setString(5, produto.getCategoria());
                        stmt.setFloat(6, produto.getQuantidade());
                        
    
                        
			stmt.executeUpdate();

			con.setAutoCommit(false);
			con.commit();
                        
                        Conexao.closeConx(con, stmt);

		

	}
   
   public static void alterarProduto(Produto produto) throws SQLException{
        PreparedStatement stmt = null;
        Connection con = null;
            
			con = Conexao.getConex();
			stmt = con.prepareStatement("update produto set nome = ?, categoria = ?, preco = ?, quantidade = ? where codBarras = ?");
                        stmt.setString(1, produto.getNome());
                        stmt.setString(2, produto.getCategoria());
                        stmt.setFloat(3, produto.getPreco());
                        stmt.setInt(4,produto.getQuantidade());
                        stmt.setString(5, produto.getCodBarras());
                        
                        
                        
                        stmt.executeUpdate();
       
       
   }
   
   
   public static void listarProduto(ArrayList<Produto> produtos) throws SQLException{
        PreparedStatement stmt = null;
        Connection con = null;
            
			con = Conexao.getConex();
			stmt = con.prepareStatement("select distinct *from produto");
                        ResultSet resultado = stmt.executeQuery();
                        
                        
                        while(resultado.next()){
                            Produto produto = new Produto();
                            produto.setNome(resultado.getString("nome"));
                            produto.setPreco(resultado.getFloat("preco"));
                            produto.setQuantidade(resultado.getInt("quantidade"));
                            produto.setCodBarras(resultado.getString("codBarras"));
                            produto.setDescricao(resultado.getString("Descricao"));
                            produto.setCategoria(resultado.getString("categoria"));
                            produto.setIdProduto(resultado.getInt("IdProduto"));
                            produtos.add(produto);
                        }
                        
                      Conexao.closeConx(con, stmt);
       
   }
    
    public static void listarCategoria(ArrayList<Produto> produtos) throws SQLException{
            PreparedStatement stmt = null;
            Connection con = null;
            
			con = Conexao.getConex();
			stmt = con.prepareStatement("select distinct categoria from categoria");
                        ResultSet resultado = stmt.executeQuery();
                        
                        
                        while(resultado.next()){
                            Produto produto = new Produto();
                            produto.setCategoria(resultado.getString("categoria"));
                            produtos.add(produto);
                        }
                      Conexao.closeConx(con, stmt);
                        
			
        
    }
    public static void adicionarCategoria(String nome) throws SQLException{
         PreparedStatement stmt = null;
        Connection con = null;
            
			con = Conexao.getConex();
			stmt = con.prepareStatement("insert into categoria (categoria) values (?)");
                        stmt.setString(1, nome);
                        stmt.executeUpdate();
                        
                
                      Conexao.closeConx(con, stmt);
       
    }
    
          public static void deletar(String nome, String codigoDeBarra) throws SQLException {
                    PreparedStatement stmt = null;
                    Connection conx = null;
                    ResultSet resultado;
                    conx = Conexao.getConex();
                    stmt = conx.prepareStatement("delete from produto where nome = ? and codBarras = ?");
                    stmt.setString(1, nome);
                    stmt.setString(2, codigoDeBarra);
                    
                    stmt.executeUpdate();
                    con.setAutoCommit(false);
                    con.commit();
	
                        
                        Conexao.closeConx(con, stmt);
			

	}
    
    
}
